

from django.urls import path, re_path
from apps.home import views

urlpatterns = [

    # The home page
    path('', views.index, name='home'),
    path('tickets/', views.getTickets, name = 'getTickets'),
    path('pend/', views.pend, name = 'pend'),
    path('create/', views.createTicket, name = 'create'),
    path('getTicket/<str:pk>', views.getTicket, name = 'getTicket'),
    path('globalID/', views.updateGlobalID, name = 'updateGlobal'),
    path('monthChart/', views.monthChart, name = 'monthChart'),
    path('adminDashboard/' , views.adminDashboard, name = "adminDashboard"),
    path("deneme/", views.deneme, name = 'deneme'),
    #path('updateTickets/', views.updateTickets, name = 'updateTickets'),
    # Matches any html file
    re_path(r'^.*\.*', views.pages, name='pages'),

]

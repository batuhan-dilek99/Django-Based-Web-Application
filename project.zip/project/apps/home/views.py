from django import template
from django.http import HttpResponse, HttpResponseRedirect
from django.template import loader
from django.urls import reverse
from .models import Ticket, TicketDataTable, Operations, Status
from django.contrib.auth.decorators import login_required
import json
from django.views.decorators.csrf import csrf_exempt
from django.shortcuts import render, redirect
from rest_framework.response import Response
from rest_framework.decorators import api_view
from django.core.paginator import Paginator
from django.template.response import TemplateResponse
from django.http import JsonResponse
from django.core import serializers
from django.forms.models import model_to_dict
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from time import sleep
import re, string, random, os

globalID = 1  #To keep track of which ticket we are processing

@login_required(login_url="/login/")
def index(request):
    context = {'segment': 'index'}

    html_template = loader.get_template('home/index.html')
    return HttpResponse(html_template.render(context, request))


@login_required(login_url="/login/")
def pages(request):
    context = {}
    # All resource paths end in .html.
    # Pick out the html file name from the url. And load that template.
    try:

        load_template = request.path.split('/')[-1]

        if load_template == 'admin':
            return HttpResponseRedirect(reverse('admin:index'))
        context['segment'] = load_template

        html_template = loader.get_template('home/' + load_template)
        return HttpResponse(html_template.render(context, request))

    except template.TemplateDoesNotExist:

        html_template = loader.get_template('home/page-404.html')
        return HttpResponse(html_template.render(context, request))

    except:
        html_template = loader.get_template('home/page-500.html')
        return HttpResponse(html_template.render(context, request))


#-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-POST METHODS-*-*-*-*-*-*-*-*-*-*-*-*--*-*-*-*-*-*


# ------handling json input from client--------

class Payload(object):

    def __init__(self, j):
        self.__dict__ = json.loads(j)


@api_view(['POST'])
@csrf_exempt
def pend(request):
    if (request.body != None):
        p = Payload(request.body)

    ticket = Ticket(firstname=p.firstname, lastname=p.lastname, email=p.email, subject=p.subjects, scenario=p.scenario,date=p.date)
    ticket.save()

    url = re.findall('https?://(?:[-\w.]|(?:%[\da-fA-F]{2}))+', ticket.scenario)

    tdt = TicketDataTable(firstname = ticket.firstname, lastname = ticket.lastname, email = ticket.email, 
        subject = ticket.subject, scenario = ticket.scenario, 
        date = ticket.date, operation_flag = Operations.get(0), status_flag = Status.get(0), domain = url)
    tdt.save()
    return Response()

#*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*

#-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-GET METHODS-*-*-*-*-*-*-*-*-*-*-*-*--*-*-*-*-*-*

@csrf_exempt
def updateGlobalID(request):
    global globalID

    if request.is_ajax():
        globalID = request.POST.get("tid")

    return Response()



@login_required()
def getTickets(request):
    tickets = TicketDataTable.objects.all().order_by("-date_created")

    p = Paginator(TicketDataTable.objects.all().order_by("-date_created"), 4)
    page = request.GET.get('page')
    ticket_list = p.get_page(page)
    nums = "a" * ticket_list.paginator.num_pages


    ticket = TicketDataTable.objects.all()

    if request.method == 'POST':
        ticket = TicketDataTable.objects.get(id = globalID)
        val = request.POST.get('op_select')

        if (val == "1"):
            ticket.operation_flag = int(val)
            ticket.status_flag = 1
            ticket.save()
            
            return redirect('http://127.0.0.1:8000/tickets/')
        elif (val == "2"):
            ticket.operation_flag = int(val)
            ticket.status_flag = 1
            ticket.save()
            
            return redirect('http://127.0.0.1:8000/tickets/')
        elif (val == "0"):
            ticket.operation_flag = int(val)
            ticket.status_flag = 0
            ticket.save()
            
            return redirect('http://127.0.0.1:8000/tickets/')
        else:
            ticket.operation_flag = int(val)
            ticket.status_flag = 0
            ticket.save()
            
            return redirect('http://127.0.0.1:8000/tickets/')

    context =  {
        'TDT' : tickets,
        'ticket_list': ticket_list,
        'nums': nums,
        'single' : ticket
    }

    return render(request, "home/ui-tables.html", context)


@login_required()
def createTicket(request):
    if request.method == 'POST':
        myuser = request.user
        firstname = myuser.first_name
        lastname = myuser.last_name
        email = myuser.email
        scenario = request.POST.get('scnr', False)
        subject = request.POST.get('sub_select', False)
        temp = re.findall('https?://(?:[-\w.]|(?:%[\da-fA-F]{2}))+', scenario)

        empty = ' '
        print()
        print(empty.join(temp))
        print()
        url = empty.join(temp)

        ticket = Ticket(firstname=firstname, lastname=lastname, email=email, scenario=scenario, subject=subject)
        ticket.save()

        tdt = TicketDataTable(firstname=ticket.firstname, lastname=ticket.lastname, email=ticket.email,
                              subject=ticket.subject, scenario=ticket.scenario, operation_flag=Operations.get(0), status_flag=Status.get(0), domain=url)
        tdt.save()


        #options = webdriver.ChromeOptions()
        #options.headless = True
        #driver = webdriver.Chrome(Options=Options)
        #URL = tdt.domain
        #driver.get(URL)
        #driver.get_screenshot_as_file("screenshot.png")

    return redirect(request.META['HTTP_REFERER'])

#sending spesific ticket data to the client-side---------------

def get_random_string(length):
    # choose from all lowercase letter
    letters = string.ascii_lowercase
    result_str = ''.join(random.choice(letters) for i in range(length))
    print("Random string of length", length, "is:", result_str)


@csrf_exempt
def getTicket(request, pk):
    ticket = TicketDataTable.objects.get(id = pk)  #gets ticket ID returns whole ticket
    ticket.status_flag = 2

    dict_obj = model_to_dict(ticket) 
    json_data = json.dumps(dict_obj)
    json_without_slash = json.loads(json_data)
    html_file_name = get_random_string(8)
    data = {
        'id' : json_without_slash,
        
    }
    return JsonResponse(data)


# extract url(s)

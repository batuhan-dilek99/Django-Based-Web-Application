from django import template
from django.http import HttpResponse, HttpResponseRedirect
from django.template import loader
from django.urls import reverse
from .models import Ticket, TicketDataTable, Operations, Status
from django.contrib.auth.decorators import login_required
import json
from django.views.decorators.csrf import csrf_exempt
from django.shortcuts import render, redirect
from rest_framework.response import Response
from rest_framework.decorators import api_view
from django.core.paginator import Paginator
from django.template.response import TemplateResponse
from django.http import JsonResponse
from django.core import serializers
from django.forms.models import model_to_dict
from time import sleep
import re, string, random, os

from selenium import webdriver
from selenium.webdriver.firefox.options import Options
from PIL import Image

globalID = 1  #To keep track of which ticket we are processing

@login_required(login_url="/login/")
def index(request):
    context = {'segment': 'index'}

    html_template = loader.get_template('home/index.html')
    return HttpResponse(html_template.render(context, request))


@login_required(login_url="/login/")
def pages(request):
    context = {}
    # All resource paths end in .html.
    # Pick out the html file name from the url. And load that template.
    try:

        load_template = request.path.split('/')[-1]

        if load_template == 'admin':
            return HttpResponseRedirect(reverse('admin:index'))
        context['segment'] = load_template

        html_template = loader.get_template('home/' + load_template)
        return HttpResponse(html_template.render(context, request))

    except template.TemplateDoesNotExist:

        html_template = loader.get_template('home/page-404.html')
        return HttpResponse(html_template.render(context, request))

    except:
        html_template = loader.get_template('home/page-500.html')
        return HttpResponse(html_template.render(context, request))


#-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-POST METHODS-*-*-*-*-*-*-*-*-*-*-*-*--*-*-*-*-*-*


# ------handling json input from client--------

class Payload(object):

    def __init__(self, j):
        self.__dict__ = json.loads(j)


@api_view(['POST'])
@csrf_exempt
def pend(request):
    if (request.body != None):
        p = Payload(request.body)

    ticket = Ticket(firstname=p.firstname, lastname=p.lastname, email=p.email, subject=p.subjects, scenario=p.scenario)
    ticket.save()

    temp = re.findall('https?://(?:[-\w.]|(?:%[\da-fA-F]{2}))+', ticket.scenario)

    empty = ' '
    print()
    print(empty.join(temp))
    print()
    url = empty.join(temp)

    options = Options()
    options.add_argument( "--headless" )
    driver = webdriver.Firefox(options=options, executable_path = "./apps/home/geckodriver")
    driver.get(url)
    imgName = get_random_string(8)
    driver.save_screenshot("./apps/static/images/" + imgName + '.png')
    driver.quit()
    imgName += '.png'
    tdt = TicketDataTable(firstname = ticket.firstname, lastname = ticket.lastname, email = ticket.email, 
        subject = ticket.subject, scenario = ticket.scenario, 
        operation_flag = Operations.get(0), status_flag = Status.get(0), domain = url, imageName = imgName)
    tdt.save()
    return Response()

#*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*

#-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-GET METHODS-*-*-*-*-*-*-*-*-*-*-*-*--*-*-*-*-*-*



#Whenever the inspect button is pressed, this function makes sure that the operations are performed on that ticket
@csrf_exempt
def updateGlobalID(request):
    global globalID

    if request.is_ajax():
        globalID = request.POST.get("tid")

    return Response()




#Renders the dashboard that shows tickets
@login_required()
def getTickets(request):
    
    #User verification--> Users can only see subject that they are assigned to
    if request.user.groups.filter(name = "bug_report"):
        tickets = TicketDataTable.objects.filter(subject = "Bug Report").order_by("-date_created").values()

    elif request.user.groups.filter(name = "false_positive"):
        tickets = TicketDataTable.objects.filter(subject = "False Positive").order_by("-date_created").values()

    elif request.user.groups.filter(name = "suggestions"):
        tickets = TicketDataTable.objects.filter(subject = "Suggestion & Ideas").order_by("-date_created").values()

    elif request.user.groups.filter(name = "academic"):
        tickets = TicketDataTable.objects.filter(subject = "Academic Request").order_by("-date_created").values()

    elif request.user.groups.filter(name = "other"):
        tickets = TicketDataTable.objects.filter(subject = "Other Topics").order_by("-date_created").values()
    else:
        tickets = TicketDataTable.objects.all().order_by("-date_created")
    #--------------------------------------------



    #Paginator-----------------------------------
    myuser = request.user
    tickets = TicketDataTable.objects.all().order_by("-date_created")

    page_num = int(request.GET.get('pg_num') or myuser.account.per_page)
    myuser.account.per_page = page_num
    myuser.account.save()

    p = Paginator(TicketDataTable.objects.all().order_by("-date_created"), page_num)
    page = request.GET.get('page')
    ticket_list = p.get_page(page)
    #--------------------------------------------


    #Submitting operation------------------------
    ticket = TicketDataTable.objects.all()
    if request.method == 'POST':
        ticket = TicketDataTable.objects.get(id = globalID)
        val = request.POST.get('op_select')

        if (val == "1"):    #Accepted
            ticket.operation_flag = int(val)
            ticket.status_flag = 1
            ticket.save()
            
            return redirect('http://127.0.0.1:8000/tickets/')
        elif (val == "2"):  #Rejected
            ticket.operation_flag = int(val)
            ticket.status_flag = 1
            ticket.save()
            
            return redirect('http://127.0.0.1:8000/tickets/')
        elif (val == "0"):  #Don't Change
            ticket.operation_flag = int(val)
            ticket.status_flag = 0
            ticket.save()
            
            return redirect('http://127.0.0.1:8000/tickets/')
        else:
            ticket.operation_flag = int(val)
            ticket.status_flag = 0
            ticket.save()
            
            return redirect('http://127.0.0.1:8000/tickets/')

    #--------------------------------------------



    context =  {
        'ticket_list': ticket_list,
    }

    return render(request, "home/ui-tables.html", context)




#Creating a ticket internally
@login_required()
def createTicket(request):

    #Getting form data--------------------
    if request.method == 'POST':
        myuser = request.user
        firstname = myuser.first_name
        lastname = myuser.last_name
        email = myuser.email
        scenario = request.POST.get('scnr', False)
        subject = request.POST.get('sub_select', False)

        #finding domains in scenario---------------
        temp = re.findall('https?://(?:[-\w.]|(?:%[\da-fA-F]{2}))+', scenario)


        #removing braces from temp object making domain pure string
        empty = ' '
        print()
        print(empty.join(temp))
        print()
        url = empty.join(temp)

        myDomain = print(request.POST.get("domain"))

        if myDomain != "None":
            options = Options()
            options.add_argument( "--headless" )
            driver = webdriver.Firefox(options=options, executable_path = "./apps/home/geckodriver")
            driver.get(url)
            imgName = get_random_string(8)
            driver.save_screenshot("./apps/static/images/" + imgName + '.png')
            driver.quit()
            imgName += '.png'

            # Saving Ticket-------
            ticket = Ticket(firstname=firstname, lastname=lastname, email=email, scenario=scenario, subject=subject)
            ticket.save()

            tdt = TicketDataTable(firstname=ticket.firstname, lastname=ticket.lastname, email=ticket.email,
                                  subject=ticket.subject, scenario=ticket.scenario, operation_flag=Operations.get(0),
                                  status_flag=Status.get(0), domain=url, imageName=imgName)
            tdt.save()
        else:
            # Saving Ticket-------
            ticket = Ticket(firstname=firstname, lastname=lastname, email=email, scenario=scenario, subject=subject)
            ticket.save()

            tdt = TicketDataTable(firstname=ticket.firstname, lastname=ticket.lastname, email=ticket.email,
                                  subject=ticket.subject, scenario=ticket.scenario, operation_flag=Operations.get(0),
                                  status_flag=Status.get(0))
            tdt.save()






    return redirect(request.META['HTTP_REFERER'])



def get_random_string(length):
    # choose from all lowercase letter
    letters = string.ascii_lowercase
    result_str = ''.join(random.choice(letters) for i in range(length))
    print("Random string of length", length, "is:", result_str)
    return result_str





#Sends ticket data to client-side to render ticket to modal
@csrf_exempt
def getTicket(request, pk):

    ticket = TicketDataTable.objects.get(id = pk)  #gets ticket ID returns whole ticket
    ticket.status_flag = 2                         #Whenever a ticket are being inspected by another user, this will lock others to reach to that ticket


    #creating a dictionary out of a model to send to the client-side
    dict_obj = model_to_dict(ticket)
    json_data = json.dumps(dict_obj)
    json_without_slash = json.loads(json_data)
    html_file_name = get_random_string(8)

    data = {
        'id' : json_without_slash,
        'imageName' : ticket.imageName,      
    }
    return JsonResponse(data)



